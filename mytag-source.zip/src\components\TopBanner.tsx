"use client";

import { useState } from "react";
import { X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function TopBanner() {
  const [isVisible, setIsVisible] = useState(true);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="bg-brand-purple text-white text-xs md:text-sm font-medium py-2 px-4 relative z-50 flex items-center justify-center overflow-hidden"
        >
          <span className="text-center">
            Get Free Embroidery on Custom Orders. Use Code - <span className="font-bold text-brand-neon">MYTAG2026</span> | Free Shipping above ₹600 | COD | Free Returns
          </span>
          <button 
            onClick={() => setIsVisible(false)}
            className="absolute right-4 hover:text-gray-300 transition-colors"
          >
            <X size={16} />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
