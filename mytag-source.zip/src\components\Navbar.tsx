"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingBag, Menu, X, Search, User, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const navLinks = [
  {
    name: "Men",
    path: "/collections/men",
    dropdown: [
      { name: "Custom T-Shirts", path: "/collections/men/t-shirts" },
      { name: "Sports Jerseys", path: "/collections/men/jerseys" },
      { name: "Premium Hoodies", path: "/collections/men/hoodies" },
    ]
  },
  {
    name: "Women",
    path: "/collections/women",
    dropdown: [
      { name: "Custom T-Shirts", path: "/collections/women/t-shirts" },
      { name: "Sports Jerseys", path: "/collections/women/jerseys" },
      { name: "Premium Hoodies", path: "/collections/women/hoodies" },
    ]
  },
  {
    name: "Collections",
    path: "/collections",
    dropdown: [
      { name: "Starter Kit", path: "/collections/starter-kit" },
      { name: "Embroidery Pro", path: "/collections/embroidery" },
      { name: "Sublimation", path: "/collections/sublimation" },
    ]
  },
  { name: "Custom Orders", path: "/custom" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <header
        className={cn(
          "fixed w-full z-40 transition-all duration-300 ease-in-out border-b border-white/5",
          scrolled ? "top-0 bg-[#050505]/95 backdrop-blur-xl py-3" : "top-10 md:top-10 bg-transparent py-4"
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <button
              className="md:hidden p-2 text-gray-300 hover:text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <Link href="/" className="flex items-center gap-2 z-50">
              <span className="text-2xl md:text-3xl font-bold font-heading tracking-tighter text-white">
                MY<span className="text-brand-neon">TAG</span>
              </span>
            </Link>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <div 
                key={link.name}
                className="relative group h-full py-2"
                onMouseEnter={() => setActiveDropdown(link.name)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href={link.path}
                  className="flex items-center gap-1 text-sm font-medium text-gray-300 hover:text-white transition-colors"
                >
                  {link.name}
                  {link.dropdown && <ChevronDown size={14} className="opacity-50 group-hover:opacity-100 group-hover:rotate-180 transition-transform" />}
                </Link>
                
                {link.dropdown && (
                  <AnimatePresence>
                    {activeDropdown === link.name && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-0 mt-4 w-56 glass border border-white/10 rounded-xl overflow-hidden shadow-2xl py-2"
                      >
                        {link.dropdown.map((item) => (
                          <Link
                            key={item.name}
                            href={item.path}
                            className="block px-4 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
                          >
                            {item.name}
                          </Link>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                )}
              </div>
            ))}
          </nav>

          <div className="flex items-center gap-4 z-50">
            <button className="p-2 text-gray-300 hover:text-white hidden md:block">
              <Search size={20} />
            </button>
            <button className="p-2 text-gray-300 hover:text-white hidden md:block">
              <User size={20} />
            </button>
            <button className="relative p-2 text-gray-300 hover:text-white transition-colors">
              <ShoppingBag size={20} />
              <span className="absolute top-0 right-0 w-4 h-4 bg-brand-neon rounded-full text-[10px] flex items-center justify-center font-bold text-black">
                0
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: "-100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "-100%" }}
            transition={{ type: "tween", duration: 0.3 }}
            className="fixed inset-0 z-50 bg-[#050505] flex flex-col pt-24 px-6 overflow-y-auto"
          >
            <button
              className="absolute top-6 right-6 p-2 text-white"
              onClick={() => setMobileMenuOpen(false)}
            >
              <X size={32} />
            </button>
            
            <div className="flex flex-col gap-6">
              {navLinks.map((link, i) => (
                <motion.div
                  key={link.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="border-b border-white/10 pb-4"
                >
                  <Link
                    href={link.path}
                    className="text-2xl font-heading font-bold text-white hover:text-brand-neon transition-colors"
                    onClick={() => !link.dropdown && setMobileMenuOpen(false)}
                  >
                    {link.name}
                  </Link>
                  {link.dropdown && (
                    <div className="mt-4 flex flex-col gap-3 pl-4">
                      {link.dropdown.map(item => (
                        <Link 
                          key={item.name} 
                          href={item.path}
                          className="text-gray-400 text-lg"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
            
            <div className="mt-auto py-8 flex gap-6 border-t border-white/10">
              <button className="flex items-center gap-2 text-gray-300">
                <User size={20} /> Account
              </button>
              <button className="flex items-center gap-2 text-gray-300">
                <Search size={20} /> Search
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
