"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Star, ChevronLeft, ChevronRight, ShoppingCart, Zap, Shield, Truck } from "lucide-react";
import TiltCard from "@/components/TiltCard";

const heroSlides = [
  {
    image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=2070&auto=format&fit=crop",
    title: "CUSTOM CLOTHING THAT REPRESENTS YOU",
    subtitle: "Premium streetwear, custom jerseys, and top-tier embroidery.",
    cta1: "Shop Men",
    link1: "/collections/men",
    cta2: "Shop Women",
    link2: "/collections/women"
  },
  {
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=2070&auto=format&fit=crop",
    title: "PREMIUM HOODIES & SWEATSHIRTS",
    subtitle: "Stay warm with our high-quality custom winter wear collection.",
    cta1: "Shop Now",
    link1: "/collections/hoodies",
    cta2: "Custom Order",
    link2: "/custom"
  },
  {
    image: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=2070&auto=format&fit=crop",
    title: "SPORTS JERSEYS FOR CHAMPIONS",
    subtitle: "High performance sublimation printing for your entire team.",
    cta1: "Explore Jerseys",
    link1: "/collections/jerseys",
    cta2: "Team Orders",
    link2: "/custom"
  }
];

const bestSellers = [
  { id: 1, name: "Neon Tag Oversized T-Shirt", price: "₹999", image: "https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=600&auto=format&fit=crop", category: "Men" },
  { id: 2, name: "Premium Street Hoodie", price: "₹1499", image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop", category: "Unisex" },
  { id: 3, name: "Pro Series Jersey", price: "₹899", image: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=600&auto=format&fit=crop", category: "Sports" },
  { id: 4, name: "Women's Comfort Scrub", price: "₹1299", image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=600&auto=format&fit=crop", category: "Women" },
  { id: 11, name: "Corporate Zip-Up Hoodie", price: "₹1699", image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=600&auto=format&fit=crop", category: "Corporate" },
  { id: 12, name: "Elite Medical Scrub Suit", price: "₹1599", image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=600&auto=format&fit=crop", category: "Medical" },
  { id: 13, name: "Premium V-Neck Scrub", price: "₹1399", image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=600&auto=format&fit=crop", category: "Unisex" },
  { id: 14, name: "Winter Fleece Pullover", price: "₹1899", image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop", category: "Men" }
];

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev === 0 ? heroSlides.length - 1 : prev - 1));

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Carousel Section */}
      <section className="relative h-[80vh] md:h-[85vh] w-full overflow-hidden">
        <AnimatePresence initial={false} mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-black/40 to-transparent z-10" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent z-10" />
            <Image
              src={heroSlides[currentSlide].image}
              alt={heroSlides[currentSlide].title}
              fill
              className="object-cover object-center"
              priority
            />
          </motion.div>
        </AnimatePresence>

        <div className="absolute inset-0 z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-end md:justify-center pb-20 md:pb-0">
          <div className="max-w-2xl">
            <motion.h1
              key={`title-${currentSlide}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl md:text-6xl lg:text-7xl font-bold font-heading tracking-tighter mb-3 md:mb-4 text-white leading-[1.1]"
            >
              {heroSlides[currentSlide].title}
            </motion.h1>
            <motion.p
              key={`desc-${currentSlide}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-base md:text-xl text-gray-300 mb-6 md:mb-8"
            >
              {heroSlides[currentSlide].subtitle}
            </motion.p>
            <motion.div
              key={`btns-${currentSlide}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-3 md:gap-4"
            >
              <Link
                href={heroSlides[currentSlide].link1}
                className="bg-brand-neon text-black px-6 md:px-8 py-3.5 rounded-sm font-bold text-base md:text-lg hover:bg-white transition-colors flex items-center justify-center gap-2"
              >
                {heroSlides[currentSlide].cta1}
              </Link>
              <Link
                href={heroSlides[currentSlide].link2}
                className="bg-transparent border border-white text-white px-6 md:px-8 py-3.5 rounded-sm font-bold text-base md:text-lg hover:bg-white hover:text-black transition-colors flex items-center justify-center"
              >
                {heroSlides[currentSlide].cta2}
              </Link>
            </motion.div>
          </div>
        </div>

        {/* Carousel Controls */}
        <button onClick={prevSlide} className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 z-30 p-2 bg-black/20 hover:bg-black/50 text-white rounded-full backdrop-blur-sm transition-all hidden md:block">
          <ChevronLeft size={32} />
        </button>
        <button onClick={nextSlide} className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 z-30 p-2 bg-black/20 hover:bg-black/50 text-white rounded-full backdrop-blur-sm transition-all hidden md:block">
          <ChevronRight size={32} />
        </button>

        {/* Indicators */}
        <div className="absolute bottom-6 md:bottom-8 left-1/2 -translate-x-1/2 z-30 flex gap-2">
          {heroSlides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={`h-1.5 transition-all duration-300 rounded-full ${i === currentSlide ? "w-6 md:w-8 bg-brand-neon" : "w-3 md:w-4 bg-white/50"}`}
            />
          ))}
        </div>
      </section>

      {/* Trust Badges - Mobile Optimized */}
      <section className="py-8 bg-[#0a0a0a] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 divide-y md:divide-y-0 md:divide-x divide-white/10">
            {[
              { icon: Zap, title: "Fast Turnaround", desc: "Quick delivery on custom orders" },
              { icon: Shield, title: "Premium Quality", desc: "Top-tier fabrics & printing" },
              { icon: Truck, title: "Pan India Shipping", desc: "Free shipping over ₹600" },
            ].map((feature, i) => (
              <div key={i} className={`flex items-center gap-4 ${i !== 0 ? 'pt-6 md:pt-0 md:pl-6' : ''}`}>
                <div className="w-12 h-12 rounded-full bg-brand-purple/20 flex items-center justify-center text-brand-neon">
                  <feature.icon size={24} />
                </div>
                <div>
                  <h4 className="text-white font-bold">{feature.title}</h4>
                  <p className="text-gray-400 text-sm">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3D Highlight Banner */}
      <section className="py-16 md:py-24 bg-[#050505] overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <span className="text-brand-neon font-bold tracking-widest uppercase mb-2 block">New Arrival</span>
              <h2 className="text-3xl md:text-5xl font-bold font-heading mb-6 text-white">THE 2026 OVERSIZED <br/> STREETWEAR DROP</h2>
              <p className="text-gray-400 text-lg mb-8">
                Experience unparalleled comfort with our new 240 GSM bio-washed heavy cotton collection. Engineered for perfect drape and durability.
              </p>
              <Link href="/collections/all" className="inline-flex items-center gap-2 text-white font-bold hover:text-brand-neon transition-colors group">
                Shop The Drop <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
            
            <div className="order-1 md:order-2 flex justify-center">
              {/* Desktop 3D Tilt Card (gracefully degrades to static on mobile touch) */}
              <TiltCard className="w-full max-w-sm aspect-[3/4]">
                <div className="w-full h-full rounded-2xl overflow-hidden shadow-2xl border border-white/10 relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-brand-purple/20 to-brand-blue/20 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <Image 
                    src="https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=800&auto=format&fit=crop" 
                    alt="Oversized Drop" 
                    fill 
                    className="object-cover"
                  />
                  <div className="absolute bottom-6 left-6 z-20 bg-black/80 backdrop-blur-md px-6 py-3 rounded-full border border-white/10">
                    <span className="text-white font-bold">₹999</span>
                  </div>
                </div>
              </TiltCard>
            </div>
          </div>
        </div>
      </section>

      {/* Shop By Category */}
      <section className="py-16 md:py-20 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold font-heading mb-2 text-white">Shop By Category</h2>
              <div className="w-16 h-1 bg-brand-neon"></div>
            </div>
            <Link href="/collections" className="text-gray-400 hover:text-brand-neon transition-colors font-medium">
              View All Categories &rarr;
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6">
            {[
              { title: "T-Shirts", img: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=500&auto=format&fit=crop" },
              { title: "Hoodies", img: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=500&auto=format&fit=crop" },
              { title: "Jerseys", img: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=500&auto=format&fit=crop" },
              { title: "Corporate", img: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=500&auto=format&fit=crop" }
            ].map((cat, i) => (
              <Link href={`/collections/${cat.title.toLowerCase()}`} key={i} className="group block">
                <div className="relative aspect-[4/5] rounded-lg md:rounded-xl overflow-hidden mb-3 md:mb-4">
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors z-10" />
                  <Image src={cat.img} alt={cat.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <h3 className="text-base md:text-lg font-bold text-center group-hover:text-brand-neon transition-colors text-white">{cat.title}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-16 md:py-20 bg-[#050505]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-12">
            <h2 className="text-3xl md:text-5xl font-bold font-heading mb-4 text-white">Best Sellers</h2>
            <div className="w-24 h-1 bg-brand-neon mx-auto"></div>
          </div>

          {/* Changed grid for mobile: 2 cols on mobile, 4 on desktop */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
            {bestSellers.map((product) => (
              <motion.div 
                key={product.id}
                whileHover={{ y: -5 }}
                className="group relative bg-[#111] rounded-lg overflow-hidden border border-white/5 hover:border-white/20 transition-all flex flex-col h-full"
              >
                <div className="relative aspect-[4/5] w-full overflow-hidden bg-white/5">
                  <Image src={product.image} alt={product.name} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute bottom-4 left-0 w-full hidden md:flex justify-center opacity-0 group-hover:opacity-100 transition-opacity translate-y-4 group-hover:translate-y-0 z-20">
                    <Link href={`/product/${product.id}`} className="bg-white text-black px-6 py-2 rounded-full font-bold text-sm flex items-center gap-2 hover:bg-brand-neon transition-colors shadow-lg">
                      <ShoppingCart size={16} /> Quick View
                    </Link>
                  </div>
                </div>
                <div className="p-3 md:p-5 flex flex-col flex-grow">
                  <span className="text-[10px] md:text-xs text-brand-neon uppercase font-bold tracking-wider">{product.category}</span>
                  <Link href={`/product/${product.id}`}>
                    <h3 className="text-sm md:text-lg font-bold mt-1 mb-2 hover:text-brand-neon transition-colors line-clamp-2 text-white">{product.name}</h3>
                  </Link>
                  <div className="mt-auto">
                    <span className="text-base md:text-xl font-medium text-white">{product.price}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-10 md:mt-12 flex justify-center">
            <Link href="/collections/all" className="w-full md:w-auto text-center border border-white/20 text-white px-8 py-3.5 rounded-sm font-bold hover:bg-white hover:text-black transition-colors">
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* Split Banners (Custom Order & Embroidery) */}
      <section className="py-4 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="grid md:grid-cols-2 gap-4 md:gap-6">
          <Link href="/custom" className="group relative h-64 md:h-80 rounded-2xl overflow-hidden block">
            <Image src="https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=800&auto=format&fit=crop" alt="Team Orders" fill className="object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] to-transparent" />
            <div className="absolute bottom-0 left-0 p-6 md:p-8">
              <span className="text-brand-neon font-bold text-sm uppercase tracking-wider mb-2 block">Bulk & Corporate</span>
              <h3 className="text-2xl md:text-3xl font-bold font-heading text-white mb-2">Team Orders</h3>
              <p className="text-gray-300 text-sm md:text-base mb-4 hidden md:block">Custom apparel tailored for your entire team or company.</p>
              <span className="text-white font-medium flex items-center gap-2 group-hover:text-brand-neon transition-colors">Explore <ArrowRight size={16} /></span>
            </div>
          </Link>
          <Link href="/collections/embroidery" className="group relative h-64 md:h-80 rounded-2xl overflow-hidden block">
            <Image src="https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=800&auto=format&fit=crop" alt="Premium Embroidery" fill className="object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] to-transparent" />
            <div className="absolute bottom-0 left-0 p-6 md:p-8">
              <span className="text-brand-purple font-bold text-sm uppercase tracking-wider mb-2 block">Premium Detail</span>
              <h3 className="text-2xl md:text-3xl font-bold font-heading text-white mb-2">Pro Embroidery</h3>
              <p className="text-gray-300 text-sm md:text-base mb-4 hidden md:block">High-precision embroidery for a permanent, luxury finish.</p>
              <span className="text-white font-medium flex items-center gap-2 group-hover:text-brand-purple transition-colors">Learn More <ArrowRight size={16} /></span>
            </div>
          </Link>
        </div>
      </section>

      {/* Starter Kit Banner */}
      <section className="py-16 md:py-24 mt-8 md:mt-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-brand-purple/20" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/80 to-transparent z-10" />
        <Image 
          src="https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=2070&auto=format&fit=crop" 
          alt="Starter Kit" 
          fill 
          className="object-cover opacity-30 mix-blend-overlay"
        />
        
        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-xl">
            <span className="text-brand-neon font-bold tracking-widest uppercase mb-3 block">Essential Packs</span>
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-bold font-heading mb-4 text-white leading-tight">STARTER KIT FOR STUDENTS & PROS</h2>
            <p className="text-base md:text-lg text-gray-300 mb-8">
              Get everything you need in one bundle. Premium quality custom apparel tailored for your institution or clinic.
            </p>
            <Link href="/collections/starter-kit" className="bg-white text-black px-6 md:px-8 py-3.5 md:py-4 rounded-sm font-bold hover:bg-brand-neon transition-colors inline-flex items-center justify-center w-full md:w-auto gap-2 text-lg">
              Shop The Kit <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Marquee Section */}
      <section className="py-6 md:py-8 border-y border-white/10 bg-[#0a0a0a] overflow-hidden">
        <div className="flex whitespace-nowrap">
          {[1, 2, 3].map((set) => (
            <motion.div
              key={set}
              animate={{ x: ["0%", "-100%"] }}
              transition={{ repeat: Infinity, ease: "linear", duration: 20 }}
              className="flex items-center gap-8 md:gap-12 px-4 md:px-6"
            >
              {["PREMIUM FABRICS", "CUSTOM EMBROIDERY", "FREE SHIPPING", "QUICK TURNAROUND", "BULK DISCOUNTS"].map((text, i) => (
                <div key={i} className="flex items-center gap-4 md:gap-8">
                  <span className="text-lg md:text-2xl font-bold font-heading text-transparent [-webkit-text-stroke:1px_#666] hover:[-webkit-text-stroke:1px_#fff] transition-all tracking-wider">
                    {text}
                  </span>
                  <Star className="text-brand-neon h-3 w-3 md:h-4 md:w-4" />
                </div>
              ))}
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
