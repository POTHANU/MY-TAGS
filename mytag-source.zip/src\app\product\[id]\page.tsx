"use client";

import { use, useState, useEffect } from "react";
import Image from "next/image";
import { Star, MessageCircle, Ruler, Plus, Minus, Check, X, Maximize2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = use(params);
  
  const product = {
    id: resolvedParams.id,
    name: "Premium Oversized T-Shirt",
    price: 999,
    description: "Our signature oversized t-shirt made with 240GSM premium cotton. Features high-quality drop shoulders and a relaxed fit perfect for streetwear styling.",
    features: [
      "100% Premium Cotton",
      "240 GSM Heavyweight Fabric",
      "Bio-washed & Pre-shrunk",
      "High density puff print",
      "Drop shoulder relaxed fit"
    ],
    // Primary image
    image: "https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=1000&auto=format&fit=crop",
    // Mockups for the gallery
    mockups: [
      "https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=1000&auto=format&fit=crop", // Main
      "https://images.unsplash.com/photo-1503341455253-b2e723bb3dbb?q=80&w=1000&auto=format&fit=crop", // Back/Alt
      "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?q=80&w=1000&auto=format&fit=crop", // Detail
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1000&auto=format&fit=crop"  // Model
    ],
    colors: [
      { name: 'Black', hex: '#111111' },
      { name: 'Navy Blue', hex: '#1e3a8a' },
      { name: 'Olive Green', hex: '#3f6212' },
      { name: 'Maroon', hex: '#7f1d1d' },
      { name: 'Ash Grey', hex: '#9ca3af' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL']
  };

  const [currentImage, setCurrentImage] = useState(product.mockups[0]);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [globalQuantity, setGlobalQuantity] = useState(1);
  const [singleSize, setSingleSize] = useState('');
  
  const [multiSizes, setMultiSizes] = useState<Record<string, number>>({
    S: 0, M: 0, L: 0, XL: 0, XXL: 0
  });

  useEffect(() => {
    if (globalQuantity >= 2) {
      const currentAllocated = Object.values(multiSizes).reduce((a, b) => a + b, 0);
      if (currentAllocated === 0 && singleSize) {
        setMultiSizes(prev => ({ ...prev, [singleSize]: globalQuantity }));
      }
    }
  }, [globalQuantity, singleSize]);

  const allocatedQuantity = Object.values(multiSizes).reduce((a, b) => a + b, 0);
  const remainingToAllocate = globalQuantity - allocatedQuantity;

  const handleMultiSizeChange = (size: string, increment: number) => {
    setMultiSizes(prev => {
      const current = prev[size];
      const next = current + increment;
      if (next < 0) return prev; 
      if (increment > 0 && remainingToAllocate <= 0) return prev; 
      return { ...prev, [size]: next };
    });
  };

  const isCheckoutDisabled = globalQuantity >= 2 ? remainingToAllocate !== 0 : singleSize === '';

  const handleWhatsApp = () => {
    if (isCheckoutDisabled) {
      if (globalQuantity >= 2) {
        alert(`Please allocate the remaining ${remainingToAllocate} items to a size.`);
      } else {
        alert("Please select a size before continuing.");
      }
      return;
    }

    let sizeText = "";
    let sizeLabel = "Sizes";
    if (globalQuantity === 1) {
      sizeText = singleSize;
      sizeLabel = "Size";
    } else {
      const selectedSizes = Object.entries(multiSizes)
        .filter(([_, qty]) => qty > 0)
        .map(([size, qty]) => `${qty}x ${size}`)
        .join(", ");
      sizeText = selectedSizes;
    }

    const totalPrice = globalQuantity * product.price;

    const defaultMessage = `Hi MYTAG, I want to order this product:
*${product.name}*
Color: ${selectedColor.name}
Quantity: ${globalQuantity}
${sizeLabel}: ${sizeText}
Total Price: ₹${totalPrice}
Link: http://localhost:3000/product/${product.id}`;

    const phoneNumber = "918309360756";
    const waUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(defaultMessage)}`;
    window.open(waUrl, "_blank");
  };

  return (
    <div className="min-h-screen bg-[#050505] py-12">
      
      {/* Lightbox Modal */}
      <AnimatePresence>
        {isLightboxOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 overflow-y-auto bg-black/95 backdrop-blur-sm"
          >
            <div className="min-h-full flex flex-col items-center justify-start p-4 pt-16 pb-32">
              <button 
                onClick={() => setIsLightboxOpen(false)}
                className="fixed top-6 right-6 text-white hover:text-brand-neon bg-white/10 p-2 rounded-full transition-colors z-[60]"
              >
                <X size={24} />
              </button>
              
              <div className="relative w-full max-w-4xl flex justify-center">
                {/* Changed to standard img tag to allow native aspect ratio scrolling without explicit height */}
                <img 
                  src={currentImage} 
                  alt="Product Zoom" 
                  className="w-full h-auto max-w-full rounded-lg shadow-2xl"
                />
              </div>

              {/* Thumbnail strip in lightbox */}
              <div className="fixed bottom-6 left-1/2 -translate-x-1/2 flex gap-3 bg-black/80 backdrop-blur-md px-4 py-3 rounded-xl border border-white/10 z-[60]">
                {product.mockups.map((mockup, i) => (
                  <button 
                    key={i} 
                    onClick={() => setCurrentImage(mockup)}
                    className={`relative w-16 h-16 rounded-md overflow-hidden border-2 transition-all ${currentImage === mockup ? 'border-brand-neon scale-110' : 'border-white/20 opacity-50 hover:opacity-100'}`}
                  >
                    <Image src={mockup} alt="thumb" fill className="object-cover" unoptimized />
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-16">
          
          {/* Product Gallery */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative sticky top-24"
          >
            {/* Main Image */}
            <div 
              className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-[#111] border border-white/5 cursor-zoom-in group mb-4"
              onClick={() => setIsLightboxOpen(true)}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent z-10 pointer-events-none" />
              <Image 
                src={currentImage} 
                alt={product.name} 
                fill 
                className="object-cover group-hover:scale-105 transition-transform duration-700"
                unoptimized
              />
              <div className="absolute top-4 right-4 z-20 bg-black/50 backdrop-blur-md p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <Maximize2 size={20} />
              </div>
            </div>

            {/* Thumbnail Mockups */}
            <div className="grid grid-cols-4 gap-3 md:gap-4">
              {product.mockups.map((mockup, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentImage(mockup)}
                  className={`relative aspect-[4/5] rounded-lg overflow-hidden border-2 transition-all ${
                    currentImage === mockup 
                      ? 'border-brand-neon opacity-100' 
                      : 'border-transparent opacity-60 hover:opacity-100 hover:border-white/20'
                  }`}
                >
                  <Image src={mockup} alt={`Mockup ${i+1}`} fill className="object-cover" unoptimized />
                </button>
              ))}
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col justify-center py-6"
          >
            <div className="mb-3 flex items-center gap-2">
              <div className="flex text-brand-neon">
                {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
              </div>
              <span className="text-gray-400 text-sm">(124 verified reviews)</span>
            </div>
            
            <h1 className="text-3xl md:text-5xl font-bold font-heading text-white mb-2">
              {product.name}
            </h1>
            <span className="text-3xl font-bold text-brand-neon mb-6 block">
              ₹{product.price}
            </span>

            <p className="text-gray-300 text-base md:text-lg mb-8 leading-relaxed">
              {product.description}
            </p>

            <div className="h-[1px] w-full bg-white/10 mb-8" />

            {/* Color Selection */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-white font-bold flex items-center gap-2">
                  Color: <span className="text-gray-400 font-normal">{selectedColor.name}</span>
                </h3>
              </div>
              <div className="flex flex-wrap gap-3">
                {product.colors.map((color) => (
                  <button 
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                      selectedColor.name === color.name ? 'ring-2 ring-brand-neon ring-offset-2 ring-offset-[#050505] scale-110' : 'ring-1 ring-white/20 hover:scale-110'
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  >
                    {selectedColor.name === color.name && <Check size={16} className={color.name === 'Ash Grey' || color.name === 'White' ? 'text-black' : 'text-white'} />}
                  </button>
                ))}
              </div>
            </div>

            {/* Global Quantity Selection */}
            <div className="mb-8">
              <h3 className="text-white font-bold mb-3">Quantity</h3>
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-white/20 rounded-md overflow-hidden h-12 w-32">
                  <button 
                    onClick={() => {
                      if (globalQuantity > 1) {
                        setGlobalQuantity(prev => prev - 1);
                        setMultiSizes({S:0, M:0, L:0, XL:0, XXL:0});
                      }
                    }}
                    className="w-10 h-full flex items-center justify-center text-white hover:bg-white/10 transition-colors"
                  >
                    <Minus size={16} />
                  </button>
                  <span className="flex-1 text-center text-white font-bold">{globalQuantity}</span>
                  <button 
                    onClick={() => {
                      setGlobalQuantity(prev => prev + 1);
                      setMultiSizes({S:0, M:0, L:0, XL:0, XXL:0}); 
                    }}
                    className="w-10 h-full flex items-center justify-center text-white hover:bg-white/10 transition-colors"
                  >
                    <Plus size={16} />
                  </button>
                </div>
                {globalQuantity >= 2 && (
                  <span className="text-brand-neon text-sm font-medium bg-brand-neon/10 px-3 py-1 rounded-full border border-brand-neon/30">
                    Bulk order unlocked
                  </span>
                )}
              </div>
            </div>

            {/* Size Selection Logic */}
            <AnimatePresence mode="wait">
              {globalQuantity < 2 ? (
                <motion.div 
                  key="single-size"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-8"
                >
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-white font-bold">Select Size</h3>
                    <button className="flex items-center gap-1 text-sm text-gray-400 hover:text-white transition-colors">
                      <Ruler size={16} /> Size Guide
                    </button>
                  </div>
                  <div className="flex gap-3">
                    {product.sizes.map((size) => (
                      <button 
                        key={size}
                        onClick={() => setSingleSize(size)}
                        className={`w-12 h-12 rounded-sm border flex items-center justify-center font-bold transition-all ${
                          singleSize === size 
                            ? 'bg-brand-neon border-brand-neon text-black' 
                            : 'border-white/20 text-white hover:border-brand-neon hover:text-brand-neon'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="multi-size"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-8 p-6 bg-[#111] rounded-xl border border-white/10"
                >
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h3 className="text-white font-bold text-lg">Distribute Sizes</h3>
                      <p className="text-sm text-gray-400 mt-1">Specify sizes for your {globalQuantity} items.</p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-bold ${remainingToAllocate === 0 ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'}`}>
                      {remainingToAllocate === 0 ? 'Fully Allocated' : `${remainingToAllocate} remaining`}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {product.sizes.map(size => (
                      <div key={size} className="flex items-center justify-between bg-black/50 p-3 rounded-lg border border-white/5">
                        <span className="text-white font-bold w-12 text-center">{size}</span>
                        <div className="flex items-center border border-white/20 rounded-md overflow-hidden h-10 w-28 bg-[#050505]">
                          <button 
                            onClick={() => handleMultiSizeChange(size, -1)}
                            className="w-8 h-full flex items-center justify-center text-white hover:bg-white/10 transition-colors disabled:opacity-30 disabled:hover:bg-transparent"
                            disabled={multiSizes[size] === 0}
                          >
                            <Minus size={14} />
                          </button>
                          <span className="flex-1 text-center text-white font-bold">{multiSizes[size]}</span>
                          <button 
                            onClick={() => handleMultiSizeChange(size, 1)}
                            className="w-8 h-full flex items-center justify-center text-white hover:bg-white/10 transition-colors disabled:opacity-30 disabled:hover:bg-transparent"
                            disabled={remainingToAllocate === 0}
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="h-[1px] w-full bg-white/10 mb-8" />

            {/* Total Price & Checkout */}
            <div className="flex items-center justify-between mb-6">
              <span className="text-gray-400 text-lg">Total</span>
              <span className="text-3xl font-bold text-white">₹{globalQuantity * product.price}</span>
            </div>

            <button 
              onClick={handleWhatsApp}
              className={`w-full text-white font-bold py-4 rounded-sm flex items-center justify-center gap-2 transition-all transform ${
                isCheckoutDisabled 
                  ? 'bg-gray-600 cursor-not-allowed opacity-70' 
                  : 'bg-green-500 hover:bg-green-600 hover:-translate-y-1 shadow-[0_0_20px_rgba(34,197,94,0.3)] hover:shadow-[0_0_30px_rgba(34,197,94,0.5)]'
              }`}
            >
              <MessageCircle size={24} /> {isCheckoutDisabled ? (globalQuantity >= 2 ? 'Complete Size Allocation' : 'Select a Size') : 'Buy Now on WhatsApp'}
            </button>

            <div className="mt-12 pt-8 border-t border-white/10">
              <h3 className="text-white font-bold mb-4 uppercase tracking-wider text-sm">Product Details</h3>
              <ul className="space-y-3">
                {product.features.map((feature, i) => (
                  <li key={i} className="text-gray-400 flex items-center gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-brand-neon" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
