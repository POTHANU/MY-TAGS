"use client";

import { useState, useEffect, use } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, Filter, X } from "lucide-react";

// Dummy product data with guaranteed working images
const dummyProducts = [
  { id: 1, name: "Neon Tag Oversized T-Shirt", price: 999, image: "https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=600&auto=format&fit=crop", category: "t-shirts", gender: "men", color: "black", neck: "round", sleeve: "half" },
  { id: 2, name: "Premium Street Hoodie", price: 1499, image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop", category: "hoodies", gender: "men", color: "grey", neck: "hood", sleeve: "full" },
  { id: 3, name: "Pro Series Jersey", price: 899, image: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=600&auto=format&fit=crop", category: "jerseys", gender: "men", color: "blue", neck: "v-neck", sleeve: "half" },
  { id: 4, name: "Women's Comfort Scrub", price: 1299, image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=600&auto=format&fit=crop", category: "t-shirts", gender: "women", color: "pink", neck: "v-neck", sleeve: "half" },
  { id: 5, name: "Women's Street Hoodie", price: 1499, image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=600&auto=format&fit=crop", category: "hoodies", gender: "women", color: "black", neck: "hood", sleeve: "full" },
  { id: 6, name: "Starter Kit Essentials", price: 2499, image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=600&auto=format&fit=crop", category: "starter-kit", gender: "unisex", color: "black", neck: "mixed", sleeve: "mixed" },
  { id: 7, name: "Classic Polo With Embroidery", price: 799, image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=600&auto=format&fit=crop", category: "t-shirts", gender: "men", color: "white", neck: "collar", sleeve: "half" },
  { id: 8, name: "Sublimation Jersey Pro", price: 1099, image: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=600&auto=format&fit=crop", category: "jerseys", gender: "unisex", color: "neon", neck: "round", sleeve: "full" },
  { id: 9, name: "Vintage Wash Drop-Shoulder", price: 899, image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=600&auto=format&fit=crop", category: "t-shirts", gender: "men", color: "grey", neck: "round", sleeve: "half" },
  { id: 10, name: "Women's Crop Top Jersey", price: 799, image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=600&auto=format&fit=crop", category: "jerseys", gender: "women", color: "blue", neck: "v-neck", sleeve: "half" },
  { id: 11, name: "Corporate Zip-Up Hoodie", price: 1699, image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop", category: "hoodies", gender: "unisex", color: "navy blue", neck: "hood", sleeve: "full" },
  { id: 12, name: "Elite Medical Scrub Suit", price: 1599, image: "https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=600&auto=format&fit=crop", category: "t-shirts", gender: "men", color: "blue", neck: "v-neck", sleeve: "half" },
  { id: 13, name: "Premium V-Neck Scrub", price: 1399, image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=600&auto=format&fit=crop", category: "t-shirts", gender: "unisex", color: "green", neck: "v-neck", sleeve: "half" },
  { id: 14, name: "Winter Fleece Pullover", price: 1899, image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=600&auto=format&fit=crop", category: "hoodies", gender: "men", color: "grey", neck: "round", sleeve: "full" }
];

export default function CollectionPage({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const resolvedParams = use(params);
  const slug = resolvedParams.slug || [];
  
  const initialCategory = slug[slug.length - 1] || "all";
  const initialGender = slug[0] === "women" ? "women" : slug[0] === "men" ? "men" : "all";

  const [products, setProducts] = useState(dummyProducts);
  const [filterCategory, setFilterCategory] = useState(initialCategory !== "women" && initialCategory !== "men" ? initialCategory : "all");
  const [filterGender, setFilterGender] = useState(initialGender);
  const [filterColor, setFilterColor] = useState("all");
  const [sortOrder, setSortOrder] = useState("featured");
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  useEffect(() => {
    let filtered = [...dummyProducts];

    // URL path filtering
    if (filterGender !== "all") {
      filtered = filtered.filter(p => p.gender === filterGender || p.gender === "unisex");
    }
    
    if (filterCategory !== "all") {
      filtered = filtered.filter(p => p.category.toLowerCase() === filterCategory.toLowerCase());
    }

    if (filterColor !== "all") {
      filtered = filtered.filter(p => p.color === filterColor);
    }

    // Sorting
    if (sortOrder === "price-low") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortOrder === "price-high") {
      filtered.sort((a, b) => b.price - a.price);
    }

    setProducts(filtered);
  }, [filterCategory, filterGender, filterColor, sortOrder]);

  const title = slug.length > 0 ? slug.join(" ").toUpperCase() : "ALL COLLECTIONS";

  return (
    <div className="min-h-screen bg-[#050505] py-8 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 md:mb-12"
        >
          <h1 className="text-3xl md:text-5xl font-bold font-heading text-white mb-4">
            {title}
          </h1>
          <p className="text-gray-400">
            Browse our premium collection. Custom fit, premium materials, and flawless printing.
          </p>
        </motion.div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Mobile Filter Toggle */}
          <div className="md:hidden flex justify-between items-center mb-4">
            <button 
              onClick={() => setIsMobileFilterOpen(true)}
              className="flex items-center gap-2 text-white bg-[#111] px-4 py-2 rounded-md border border-white/10"
            >
              <Filter size={18} /> Filters
            </button>
            <span className="text-gray-400 text-sm">{products.length} products</span>
          </div>

          {/* Sidebar Filters */}
          <div className={`fixed inset-0 z-50 bg-[#050505] p-6 overflow-y-auto md:static md:bg-transparent md:p-0 md:w-64 md:flex-shrink-0 md:block ${isMobileFilterOpen ? "block" : "hidden"}`}>
            {isMobileFilterOpen && (
              <div className="flex justify-between items-center mb-8 md:hidden">
                <h2 className="text-2xl font-bold text-white">Filters</h2>
                <button onClick={() => setIsMobileFilterOpen(false)} className="text-white"><X size={24} /></button>
              </div>
            )}

                <div className="space-y-8">
                  {/* Category Filter */}
                  <div>
                    <h3 className="text-white font-bold mb-4 uppercase text-sm tracking-wider">Product Type</h3>
                    <ul className="space-y-3">
                      {["all", "t-shirts", "hoodies", "jerseys", "starter-kit"].map(cat => (
                        <li key={cat}>
                          <label className="flex items-center gap-3 cursor-pointer text-gray-400 hover:text-white transition-colors">
                            <input 
                              type="radio" 
                              name="category" 
                              checked={filterCategory === cat} 
                              onChange={() => setFilterCategory(cat)}
                              className="accent-brand-neon bg-[#111]"
                            />
                            <span className="capitalize">{cat.replace("-", " ")}</span>
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Gender Filter */}
                  <div>
                    <h3 className="text-white font-bold mb-4 uppercase text-sm tracking-wider">Gender</h3>
                    <ul className="space-y-3">
                      {["all", "men", "women"].map(gen => (
                        <li key={gen}>
                          <label className="flex items-center gap-3 cursor-pointer text-gray-400 hover:text-white transition-colors">
                            <input 
                              type="radio" 
                              name="gender" 
                              checked={filterGender === gen} 
                              onChange={() => setFilterGender(gen)}
                              className="accent-brand-neon bg-[#111]"
                            />
                            <span className="capitalize">{gen}</span>
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Color Filter */}
                  <div>
                    <h3 className="text-white font-bold mb-4 uppercase text-sm tracking-wider">Color</h3>
                    <div className="flex flex-wrap gap-3">
                      {["all", "black", "white", "grey", "blue", "pink", "neon"].map(col => (
                        <button
                          key={col}
                          onClick={() => setFilterColor(col)}
                          className={`w-8 h-8 rounded-full border-2 transition-all ${filterColor === col ? "border-brand-neon scale-110" : "border-white/20 hover:border-white/50"}`}
                          style={{ backgroundColor: col === "all" ? "transparent" : col === "neon" ? "#00f2fe" : col }}
                          title={col}
                        >
                          {col === "all" && <span className="text-[10px] text-white">All</span>}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

            {isMobileFilterOpen && (
              <button 
                onClick={() => setIsMobileFilterOpen(false)}
                className="w-full bg-brand-neon text-black font-bold py-3 mt-8 rounded-md md:hidden"
              >
                Apply Filters
              </button>
            )}
          </div>

          {/* Product Grid Area */}
          <div className="flex-grow">
            <div className="hidden md:flex justify-between items-center mb-8 border-b border-white/10 pb-4">
              <span className="text-gray-400 text-sm">{products.length} products found</span>
              <div className="flex items-center gap-4">
                <span className="text-gray-400 text-sm">Sort by:</span>
                <select 
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value)}
                  className="bg-transparent border border-white/20 text-white text-sm rounded-sm px-3 py-1.5 focus:outline-none focus:border-brand-neon"
                >
                  <option value="featured" className="bg-black">Featured</option>
                  <option value="price-low" className="bg-black">Price: Low to High</option>
                  <option value="price-high" className="bg-black">Price: High to Low</option>
                </select>
              </div>
            </div>

            {/* Products Grid with Framer Motion */}
            <motion.div 
              layout
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              <AnimatePresence>
                {products.length === 0 ? (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="col-span-full py-20 text-center text-gray-500"
                  >
                    No products found matching your filters.
                  </motion.div>
                ) : (
                  products.map((product, i) => (
                    <motion.div 
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.3, delay: i * 0.05 }}
                      key={product.id}
                      className="group relative bg-[#111] rounded-lg overflow-hidden border border-white/5 hover:border-white/20 transition-all"
                    >
                      <Link href={`/product/${product.id}`} className="block relative h-80 w-full overflow-hidden bg-white/5">
                        <Image src={product.image} alt={product.name} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                        <div className="absolute bottom-4 left-0 w-full flex justify-center opacity-0 group-hover:opacity-100 transition-opacity translate-y-4 group-hover:translate-y-0 z-20">
                          <button className="bg-white text-black px-6 py-2 rounded-full font-bold text-sm flex items-center gap-2 hover:bg-brand-neon transition-colors">
                            <ShoppingCart size={16} /> Quick Add
                          </button>
                        </div>
                      </Link>
                      <div className="p-5">
                        <span className="text-[10px] text-brand-neon uppercase font-bold tracking-widest">{product.category} • {product.gender}</span>
                        <Link href={`/product/${product.id}`}>
                          <h3 className="text-lg font-bold mt-1 mb-2 hover:text-brand-neon transition-colors truncate">{product.name}</h3>
                        </Link>
                        <div className="flex justify-between items-center">
                          <span className="text-xl font-medium">₹{product.price}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
