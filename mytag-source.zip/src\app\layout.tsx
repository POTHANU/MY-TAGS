import type { Metadata } from "next";
import { Inter, Outfit } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import SmoothScroll from "@/components/SmoothScroll";
import WhatsAppButton from "@/components/WhatsAppButton";
import TopBanner from "@/components/TopBanner";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const outfit = Outfit({
  variable: "--font-outfit",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MYTAG Custom Clothing Store",
  description: "Premium custom streetwear, embroidery, and jersey printing in Visakhapatnam.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${outfit.variable} dark antialiased`}>
      <body className="min-h-screen flex flex-col bg-background text-foreground">
        <SmoothScroll>
  return (
    <html lang="en" className={`${inter.variable} ${outfit.variable} dark antialiased`}>
      <body className="min-h-screen flex flex-col bg-background text-foreground">
        <SmoothScroll>
          <TopBanner />
          <Navbar />
          <main className="flex-grow pt-[100px] md:pt-[120px]">
            {children}
          </main>
          {/* Footer will go here */}
          <WhatsAppButton />
        </SmoothScroll>
      </body>
    </html>
  );
        </SmoothScroll>
      </body>
    </html>
  );
}
