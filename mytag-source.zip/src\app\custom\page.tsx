"use client";

import { useState, useRef } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, Upload, X, Move, Maximize, FlipHorizontal, Check } from "lucide-react";

const APPAREL_COLORS = [
  { name: 'White', hex: '#ffffff' },
  { name: 'Black', hex: '#222222' },
  { name: 'Navy Blue', hex: '#1e3a8a' },
  { name: 'Olive Green', hex: '#3f6212' },
  { name: 'Maroon', hex: '#7f1d1d' },
  { name: 'Neon Blue', hex: '#00f2fe' },
];

// Using Unsplash images. For perfect coloring without background bleed in production, replace these with Transparent PNGs.
const apparelBases: Record<string, string> = {
  "T-Shirt": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=800&auto=format&fit=crop", 
  "Hoodie": "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=800&auto=format&fit=crop",
  "Jersey": "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=800&auto=format&fit=crop",
};

export default function CustomOrderPage() {
  const phoneNumber = "918309360756";
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState("");
  const [apparelType, setApparelType] = useState("T-Shirt");
  const [apparelColor, setApparelColor] = useState(APPAREL_COLORS[0]);
  const [viewSide, setViewSide] = useState<"front" | "back">("front");
  const [quantity, setQuantity] = useState("10");
  
  // Design states
  const [uploadedLogo, setUploadedLogo] = useState<string | null>(null);
  const [logoSize, setLogoSize] = useState(120);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setUploadedLogo(imageUrl);
    }
  };

  const removeLogo = () => {
    setUploadedLogo(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    const hasLogo = uploadedLogo ? "Yes, I have a logo ready." : "No logo uploaded yet.";
    const placement = uploadedLogo ? `(Placed on ${viewSide})` : "";
    
    const defaultMessage = `Hi MYTAG, I want to place a custom order!
*Name:* ${name || 'Customer'}
*Apparel:* ${apparelType}
*Color:* ${apparelColor.name}
*Quantity:* ${quantity}
*Design:* ${hasLogo} ${placement}

Let's discuss pricing and details.`;

    const waUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(defaultMessage)}`;
    window.open(waUrl, "_blank");
  };

  return (
    <div className="min-h-screen bg-[#050505] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <span className="text-brand-neon font-bold tracking-widest uppercase mb-2 block">Interactive Studio</span>
          <h1 className="text-4xl md:text-6xl font-bold font-heading text-white mb-4">
            Design <span className="text-brand-neon">Your Own</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Choose a color, upload your logo, and instantly preview how it looks on the front or back.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          
          {/* Interactive Mockup Visualizer */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-[#111] p-6 rounded-2xl border border-white/10"
          >
            {/* Color & Type Controls Header */}
            <div className="flex flex-col mb-6 gap-4">
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  {Object.keys(apparelBases).map((type) => (
                    <button
                      key={type}
                      onClick={() => setApparelType(type)}
                      className={`text-xs px-3 py-1.5 rounded-full font-bold transition-colors ${
                        apparelType === type 
                          ? "bg-brand-neon text-black" 
                          : "bg-white/5 text-gray-400 hover:text-white border border-white/10"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
                <button 
                  onClick={() => setViewSide(prev => prev === "front" ? "back" : "front")}
                  className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white text-sm px-4 py-2 rounded-full font-bold transition-colors border border-white/20"
                >
                  <FlipHorizontal size={16} /> 
                  View {viewSide === "front" ? "Back" : "Front"}
                </button>
              </div>

              {/* Color Swatches */}
              <div>
                <span className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-2 block">Apparel Color</span>
                <div className="flex gap-3">
                  {APPAREL_COLORS.map(color => (
                    <button 
                      key={color.name}
                      onClick={() => setApparelColor(color)}
                      className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                        apparelColor.name === color.name ? 'ring-2 ring-brand-neon ring-offset-2 ring-offset-[#111] scale-110' : 'ring-1 ring-white/20 hover:scale-110'
                      }`}
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                    >
                      {apparelColor.name === color.name && <Check size={14} className={color.hex === '#ffffff' ? 'text-black' : 'text-white'} />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* The Mockup Area */}
            <div className="relative w-full aspect-[4/5] bg-[#e5e5e5] rounded-xl border border-white/5 overflow-hidden flex items-center justify-center">
              
              {/* The Base Apparel Image with dynamic flipping */}
              <div className={`absolute inset-0 transition-transform duration-500 ease-in-out ${viewSide === 'back' ? 'scale-x-[-1]' : ''}`}>
                <Image 
                  src={apparelBases[apparelType]} 
                  alt={apparelType} 
                  fill 
                  className="object-cover"
                  unoptimized
                />
              </div>

              {/* Dynamic Color Overlay using mix-blend-multiply */}
              {/* Note: This colors the whole image because Unsplash images are JPEGs without transparency. */}
              <div 
                className={`absolute inset-0 mix-blend-multiply pointer-events-none transition-colors duration-300 ${viewSide === 'back' ? 'scale-x-[-1]' : ''}`}
                style={{ 
                  backgroundColor: apparelColor.hex === '#ffffff' ? 'transparent' : apparelColor.hex
                }}
              />
              
              {/* Contrast booster for dark colors */}
              <div className="absolute inset-0 bg-black/5 pointer-events-none z-10" />

              {uploadedLogo ? (
                <motion.div
                  drag
                  dragConstraints={{ top: -250, left: -150, right: 150, bottom: 250 }}
                  dragElastic={0}
                  dragMomentum={false}
                  whileHover={{ scale: 1.05 }}
                  whileDrag={{ scale: 1.1, cursor: "grabbing" }}
                  className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 cursor-grab origin-center"
                >
                  <img 
                    src={uploadedLogo} 
                    alt="Custom Logo" 
                    style={{ width: `${logoSize}px` }}
                    className="h-auto drop-shadow-2xl transition-all duration-100"
                    draggable={false}
                  />
                  <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black/80 text-white text-[10px] px-2 py-1 rounded-full opacity-0 hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none flex items-center gap-1">
                    <Move size={10} /> Drag to position
                  </div>
                </motion.div>
              ) : (
                <div className="absolute inset-0 z-20 flex items-center justify-center pointer-events-none">
                  <div className="border-2 border-dashed border-white/20 rounded-xl p-8 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm">
                    <Upload className="text-white/30 mb-2" size={32} />
                    <span className="text-white/50 font-medium text-center">Upload a logo for the {viewSide} <br/>of the {apparelColor.name} {apparelType}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Logo Controls */}
            {uploadedLogo && (
              <div className="mt-4 p-4 bg-black/50 border border-white/10 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm text-gray-400 flex items-center gap-2">
                    <Maximize size={14} /> Resize Logo
                  </label>
                  <span className="text-xs text-brand-neon font-bold">{logoSize}px</span>
                </div>
                <input 
                  type="range" 
                  min="40" 
                  max="350" 
                  value={logoSize} 
                  onChange={(e) => setLogoSize(Number(e.target.value))}
                  className="w-full accent-brand-neon"
                />
              </div>
            )}

            <div className="mt-4 flex gap-4">
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold py-3 rounded-md flex items-center justify-center gap-2 transition-colors"
              >
                <Upload size={18} /> {uploadedLogo ? "Change Logo" : "Upload Logo"}
              </button>
              {uploadedLogo && (
                <button 
                  onClick={removeLogo}
                  className="bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20 font-bold px-4 rounded-md flex items-center justify-center transition-colors"
                  title="Remove Logo"
                >
                  <X size={20} />
                </button>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                accept="image/*" 
                className="hidden" 
              />
            </div>
          </motion.div>

          {/* Quote Request Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-col justify-center h-full"
          >
            <div className="mb-8">
              <h2 className="text-3xl font-bold mb-4 text-white">Get a Custom Quote</h2>
              <p className="text-gray-400">
                Happy with how your logo looks on the {apparelColor.name} {apparelType}? Fill out the details below and we'll connect with you on WhatsApp instantly.
              </p>
            </div>

            <form onSubmit={handleWhatsApp} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Your Name / Brand Name</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#111] border border-white/10 rounded-md px-4 py-4 text-white focus:outline-none focus:border-brand-neon transition-colors" 
                  placeholder="E.g., John Doe or TechCorp"
                  required 
                />
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Apparel Type</label>
                  <select 
                    value={apparelType}
                    onChange={(e) => {
                      setApparelType(e.target.value);
                      setViewSide("front");
                    }}
                    className="w-full bg-[#111] border border-white/10 rounded-md px-4 py-4 text-white focus:outline-none focus:border-brand-neon transition-colors"
                  >
                    <option value="T-Shirt">T-Shirts</option>
                    <option value="Hoodie">Hoodies</option>
                    <option value="Jersey">Jerseys</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Est. Quantity</label>
                  <input 
                    type="number" 
                    min="1" 
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full bg-[#111] border border-white/10 rounded-md px-4 py-4 text-white focus:outline-none focus:border-brand-neon transition-colors" 
                    required 
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-white/10">
                <button
                  type="submit"
                  className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-5 rounded-md flex items-center justify-center gap-3 transition-colors shadow-lg shadow-green-500/20 text-lg"
                >
                  <MessageCircle size={24} /> Submit Design via WhatsApp
                </button>
              </div>
            </form>
            
            <div className="mt-8 text-sm text-gray-500 flex items-start gap-2">
              <span className="text-brand-neon">*</span>
              <p>This visualizer uses mix-blend technology to dynamically preview colors. Final production colors will be matched using physical swatch codes.</p>
            </div>
          </motion.div>

        </div>
      </div>
    </div>
  );
}
